"""Gate 2: high-risk classification (Art. 6 + Annex III AIA).

Two routes to high-risk: the Annex I product-safety route (Art. 6(1)) and the
Annex III use-case route (Art. 6(2)). The Annex III route is subject to the
Art. 6(3) derogation, but profiling of natural persons forecloses the
derogation entirely (Art. 6(3), third subparagraph). An asserted-but-unconfirmed
derogation is not silently applied: the system stays high-risk and the call is
handed to review, because Art. 6(3)/(4) require a documented assessment before
a system leaves the high-risk tier.
"""

from __future__ import annotations

from ..catalog import ANNEX_III, SECTION_B_PROVISIONS, section_b_annex_iii_flag
from ..citations import ART_2_13, ART_6_1C, Citation
from ..models import AnnexIII, AnnexISection, Finding, RiskTier, Severity
from ..transitions import annex_i_route, derogation_asserted, section_b_product
from .base import GateOutput

# Art. 6(1c) AIA, inserted by Regulation (EU) 2026/1744, Art. 1, point (8). Its own finding,
# whose citation_verified follows ART_6_1C (VERIFIED ledger row, read 11 November 2026).
_ART_6_1C = (
    "A third-party conformity assessment required solely for risks other than risks to "
    "health and safety, such as radio spectrum or electromagnetic interference, does not "
    "meet Art. 6(1)(b) (Art. 6(1c) AIA)."
)
# Art. 2(13), added by Regulation (EU) 2026/1744, Art. 1, point (3), lets delegated acts
# limit some duties for Section A. Its own finding too (VERIFIED ledger row).
_ART_2_13 = (
    "Delegated acts under Art. 2(13) AIA, due by 2 August 2027, may limit Arts. 9 to 15 and "
    "17 to 25 where the Section A legislation gives an equivalent or higher level of "
    "protection and the limitation does not reduce the overall level of protection provided "
    "for by the AI Act."
)
# Art. 2(2) AIA limits a Section B product; Regulation (EU) 2026/1744, Art. 1, point (41)
# moved machinery there (Section A, point 1 deleted; Section B, point 21 added).
_ANNEX_I_SECTION_NOTE: dict[AnnexISection | None, str] = {
    AnnexISection.SECTION_A: "Annex I, Section A: the Chapter III duties apply.",
    AnnexISection.SECTION_B: (
        f"Annex I, Section B: {SECTION_B_PROVISIONS} (Art. 2(2) AIA), so no Chapter III "
        "duty attaches through this route."
    ),
    None: (
        "Annex I section not given, so treated as Section A. For a Section B product, "
        "including machinery under Regulation (EU) 2023/1230 since Regulation (EU) "
        f"2026/1744, {SECTION_B_PROVISIONS} (Art. 2(2) AIA)."
    ),
}


def _pinpoint_note(rule_id: str, citation: Citation, title: str, detail: str) -> Finding:
    """A statement on the Annex I route with a pinpoint of its own: its own finding, so the
    citation's verification status shows in every output."""

    return Finding(
        rule_id=rule_id,
        citation=citation.ref,
        citation_verified=citation.verified,
        title=title,
        detail=detail,
        severity=Severity.INFO,
    )


def evaluate(profile) -> GateOutput:
    out = GateOutput()

    # Route 1: Annex I product-safety (Art. 6(1))
    if annex_i_route(profile):
        out.tier_vote = RiskTier.HIGH
        detail = (
            "Safety component of, or itself, a product covered by Annex I harmonisation "
            "legislation requiring third-party conformity assessment. "
            f"{_ANNEX_I_SECTION_NOTE[profile.annex_i_section]}"
        )
        if section_b_product(profile) and profile.annex_iii_area is not None:
            detail += f" {section_b_annex_iii_flag(derogation_asserted(profile))}"
        out.findings.append(
            Finding(
                rule_id="HIGHRISK.6.1",
                citation="Art. 6(1) AIA",
                title="High-risk via the Annex I product-safety route",
                detail=detail,
                severity=Severity.HIGH,
                tier=RiskTier.HIGH,
            )
        )
        out.findings.append(
            _pinpoint_note(
                "HIGHRISK.6.1c", ART_6_1C, "Annex I route: assessment for other risks", _ART_6_1C
            )
        )
        if profile.annex_i_section is AnnexISection.SECTION_A:
            out.findings.append(
                _pinpoint_note(
                    "HIGHRISK.2.13", ART_2_13, "Annex I, Section A: delegated acts", _ART_2_13
                )
            )

    elif profile.annex_i_section is not None:
        # The section only sorts an Art. 6(1) product; say so rather than drop it silently.
        out.findings.append(
            Finding(
                rule_id="HIGHRISK.6.1.section_unused",
                citation="Art. 6(1) AIA",
                title="Annex I section given without the Art. 6(1) route",
                detail=(
                    f"annex_i_section is {profile.annex_i_section.value}, but the profile does "
                    "not assert both an Annex I product or safety component and a third-party "
                    "conformity assessment, so the Art. 6(1) route and the section are not used."
                ),
                severity=Severity.INFO,
            )
        )

    # Route 2: Annex III use cases (Art. 6(2))
    area = profile.annex_iii_area
    if area is None:
        return out

    citation, label = ANNEX_III[area]

    if area is AnnexIII.UNSURE:
        out.tier_vote = RiskTier.HIGH  # conservative default while the point is pinned
        out.findings.append(
            Finding(
                rule_id="HIGHRISK.III.unsure",
                citation=citation.ref,
                citation_verified=citation.verified,
                title="Potentially high-risk: Annex III area implicated",
                detail="An Annex III use case appears implicated but the point is unsettled.",
                severity=Severity.HIGH,
                tier=RiskTier.HIGH,
            )
        )
        out.open_questions.append(
            "Confirm which Annex III point applies (Art. 6(2) AIA); the system is treated "
            "as high-risk until the point is settled."
        )
        return out

    if area is AnnexIII.CREDITWORTHINESS:
        question = _fraud_exception_question(profile.used_for_financial_fraud_detection)
        if question:
            out.open_questions.append(question)

    derog = profile.derogation
    if derog.performs_profiling:
        out.tier_vote = RiskTier.HIGH
        out.findings.append(
            Finding(
                rule_id=f"HIGHRISK.{area.value}",
                citation=citation.ref,
                citation_verified=citation.verified,
                title=f"High-risk: {label}",
                detail=(
                    "Annex III high-risk area. Profiling of natural persons keeps the system "
                    "high-risk despite any derogation (Art. 6(3), third subparagraph, AIA)."
                ),
                severity=Severity.HIGH,
                tier=RiskTier.HIGH,
            )
        )
        return out

    if derog.any_condition:
        out.tier_vote = RiskTier.HIGH  # stays high-risk until the derogation is established
        if section_b_product(profile):
            effect = (
                "which may take the system out of the Annex III route. It stays high-risk "
                "under Art. 6(1), and if the derogation is established only the Art. 2(2) "
                "AIA provisions apply to it."
            )
        elif annex_i_route(profile):
            effect = (
                "which may take the system out of the Annex III route. It stays high-risk "
                "under Art. 6(1)."
            )
        else:
            effect = "which may downgrade the system to minimal risk."
        out.findings.append(
            Finding(
                rule_id=f"HIGHRISK.{area.value}.derogation",
                citation="Art. 6(3) AIA",
                title=f"High-risk pending Art. 6(3) derogation: {label}",
                detail=(
                    f"{label} ({citation.ref}). A derogation condition is asserted and no "
                    f"profiling is performed, {effect}"
                ),
                severity=Severity.MEDIUM,
                tier=RiskTier.HIGH,
            )
        )
        out.open_questions.append(
            f"Art. 6(3) derogation asserted for {citation.ref}: confirm the system does not "
            "pose a significant risk of harm and does not materially influence the outcome "
            "of decision-making. The assessment must be documented (Art. 6(4) AIA). If it "
            "does, the system remains high-risk."
        )
        return out

    out.tier_vote = RiskTier.HIGH
    out.findings.append(
        Finding(
            rule_id=f"HIGHRISK.{area.value}",
            citation=citation.ref,
            citation_verified=citation.verified,
            title=f"High-risk: {label}",
            detail="Annex III high-risk area (Art. 6(2) AIA); no derogation asserted.",
            severity=Severity.HIGH,
            tier=RiskTier.HIGH,
        )
    )
    return out


def _fraud_exception_question(used_for_fraud_detection: bool | None) -> str | None:
    """Review question for the financial-fraud exception in Annex III(5)(b) AIA.

    The exception is not applied silently: an asserted or unknown fraud-detection
    purpose keeps the system high-risk and hands the characterisation to review.
    """
    if used_for_fraud_detection is False:
        return None
    if used_for_fraud_detection is None:
        return (
            "Annex III(5)(b) AIA excepts AI systems used for the purpose of detecting "
            "financial fraud. Confirm whether that exception applies to this system; it is "
            "treated as high-risk until that is settled."
        )
    return (
        "Annex III(5)(b) AIA excepts AI systems used for the purpose of detecting financial "
        "fraud, and the profile states that this system is used for that purpose. Confirm "
        "whether it also evaluates the creditworthiness of natural persons or establishes "
        "their credit score; it is treated as high-risk until that is settled."
    )
