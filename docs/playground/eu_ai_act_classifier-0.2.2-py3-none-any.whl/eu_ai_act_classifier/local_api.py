"""Local JSON bridge used by the optional web cockpit.

The bridge keeps the Python classifier as the legal source of truth while the
Next.js app provides a local UI and route surface.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from .artifacts import ARTIFACT_NAMES, _slug, render_artifact, selected_artifacts
from .citations import source_manifest
from .collaboration_workspace import apply_workspace_action
from .dossier import REVIEW_DOSSIER_SCHEMA, build_review_dossier
from .engine import classify
from .inventory import build_example_inventory
from .models import (
    AnnexIII,
    AnnexISection,
    ExcludedUse,
    ProhibitedPractice,
    Role,
    SystemProfile,
)
from .portfolio_workspace import build_example_portfolio_workspace

# The whole stderr line for any failure other than invalid input (exit 1).
INTERNAL_ERROR = "the classifier bridge failed"


def schema_payload() -> dict[str, Any]:
    return {
        "roles": [role.value for role in Role],
        "annex_iii_areas": [area.value for area in AnnexIII],
        "annex_i_sections": [section.value for section in AnnexISection],
        "prohibited_practices": [practice.value for practice in ProhibitedPractice],
        "excluded_use_flags": [flag.value for flag in ExcludedUse],
        "artifacts": sorted(ARTIFACT_NAMES),
        "dossier_schema": REVIEW_DOSSIER_SCHEMA,
        "review_posture": "draft_only_human_review_required",
    }


def classify_payload(payload: dict[str, Any]) -> dict[str, Any]:
    profile_data = payload.get("profile", payload)
    include_advisory = bool(payload.get("include_advisory", False))
    report = classify(
        SystemProfile.model_validate(profile_data),
        include_advisory=include_advisory,
    )
    return report.model_dump(mode="json")


def sources_payload() -> list[dict[str, Any]]:
    return [source.model_dump(mode="json") for source in source_manifest()]


def inventory_payload() -> dict[str, Any]:
    return build_example_inventory().model_dump(mode="json", by_alias=True)


def workspace_payload() -> dict[str, Any]:
    return build_example_portfolio_workspace().model_dump(mode="json", by_alias=True)


def artifacts_payload(payload: dict[str, Any]) -> dict[str, Any]:
    profile_data = payload.get("profile", payload)
    include_advisory = bool(payload.get("include_advisory", False))
    selection = str(payload.get("artifact", "all"))
    report = classify(
        SystemProfile.model_validate(profile_data),
        include_advisory=include_advisory,
    )
    return {
        "system": report.system,
        "review_status": "draft_only_human_review_required",
        "artifacts": [
            {
                "name": artifact_name,
                # The name write_artifacts gives the file, so the CLI and cockpit agree.
                "filename": f"{_slug(report.system)}.{artifact_name}.md",
                "content": render_artifact(artifact_name, report),
            }
            for artifact_name in selected_artifacts(selection)
        ],
        "source_manifest": [source.model_dump(mode="json") for source in report.source_manifest],
    }


def dossier_payload(payload: dict[str, Any]) -> dict[str, Any]:
    profile_data = payload.get("profile", payload)
    include_advisory = bool(payload.get("include_advisory", False))
    artifact_selection = str(payload.get("artifact", "all"))
    report = classify(
        SystemProfile.model_validate(profile_data),
        include_advisory=include_advisory,
    )
    return build_review_dossier(
        report,
        artifact_selection=artifact_selection,
    ).model_dump(mode="json", by_alias=True)


def _print_error(message: str) -> None:
    print(json.dumps({"error": message}), file=sys.stderr)


def _validation_message(exc: ValidationError) -> str:
    """Pydantic's summary of ``exc`` without the rejected values.

    Pydantic's own message repeats each rejected value (``input_value=...``) and links
    its documentation. This keeps the header, each field path and each reason only.
    """

    count = exc.error_count()
    lines = [f"{count} validation error{'' if count == 1 else 's'} for {exc.title}"]
    for error in exc.errors(include_url=False, include_context=False, include_input=False):
        location = ".".join(str(part) for part in error["loc"])
        if location:
            lines.append(location)
        lines.append(f"  {error['msg']}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="eu-ai-act-local-api")
    parser.add_argument(
        "command",
        choices=[
            "schema",
            "classify",
            "sources",
            "inventory",
            "workspace",
            "collaboration",
            "artifacts",
            "dossier",
        ],
    )
    args = parser.parse_args(argv)

    try:
        payload = _read_payload()
        if args.command == "schema":
            result: Any = schema_payload()
        elif args.command == "classify":
            result = classify_payload(payload)
        elif args.command == "sources":
            result = sources_payload()
        elif args.command == "inventory":
            result = inventory_payload()
        elif args.command == "workspace":
            result = workspace_payload()
        elif args.command == "collaboration":
            result = apply_workspace_action(
                payload,
                Path("runtime-data/collaboration-workspace.json"),
            )
        elif args.command == "artifacts":
            result = artifacts_payload(payload)
        else:
            result = dossier_payload(payload)
    except ValidationError as exc:
        # Exit 2 with one JSON line on stderr: web/lib/bridge-error.ts reads this as invalid
        # input (HTTP 400) and returns the message; any other exit becomes HTTP 500.
        _print_error(_validation_message(exc))
        return 2
    except ValueError as exc:
        _print_error(str(exc))
        return 2
    except Exception:
        # A traceback would carry absolute paths and the values being processed, and
        # the cockpit used to pass stderr on to the HTTP client.
        _print_error(INTERNAL_ERROR)
        return 1

    print(json.dumps(result, indent=2))
    return 0


def _read_payload() -> dict[str, Any]:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("payload must be a JSON object")
    return data


if __name__ == "__main__":
    raise SystemExit(main())
