"""The guided-intake definition: questions, their order and when each is asked.

This module is the single source for every guided-intake surface. The
playground reads it from ``docs/playground/intake.json``, which
``scripts/build_playground.py`` generates; the browser only interprets the
declarative conditions below and holds no legal logic of its own.

Each question collects one characterised fact, or a small set of facts the
engine reads together. The intake never infers a fact. "I don't know" is
handled per question and never becomes ``false`` or an omitted field:

* ``{"value": ...}`` writes a fail-closed value: ``null`` for a nullable screen
  the engine routes to review, ``III.unsure`` for the Annex III point.
* ``"block"`` stops the run: counsel must characterise the fact before the
  profile can be classified.

A question is skipped only where ``tests/test_intake.py`` checks, over grids of
states the intake can reach, that no answer to it changes the classification
report, apart from the engine's own statement that a value given there is not
used. Nonbinding advisory notes are outside that check: they may still reflect a
screen the intake skips for a profile outside the AI Act's scope.
"""

from __future__ import annotations

import math
import re
from typing import Any

from .citations import POINT_C_ANNEX_I, POINT_C_ANNEX_III
from .labels import DEROGATION_LABELS, option_label
from .models import (
    AnnexIII,
    AnnexILegislation,
    AnnexISection,
    ExcludedUse,
    ProhibitedPractice,
    Role,
    SystemProfile,
)

SCHEMA_ID = "eu-ai-act-classifier.intake.v1"
BLOCK = "block"
UNKNOWN = "unknown"

# Conditions are plain data so the browser can evaluate exactly what Python does:
#   {"field": f, "is": v}      the field equals v (v may be null)
#   {"field": f, "in": [..]}   the field equals one of the values
#   {"field": f, "has": v}     the list field contains v
#   {"field": f, "empty": b}   the list field is (not) empty
#   {"field": f, "before": d}  the date field is given and earlier than ISO date d
#   {"all": [..]}, {"any": [..]}, {"not": c}
# Fields are profile fields; "derogation.x" reads a nested Derogation flag.

IN_SCOPE = {
    "all": [
        {"not": {"field": "is_ai_system", "is": False}},
        {"not": {"field": "eu_nexus", "is": False}},
    ]
}
# Includes III.unsure: an asserted Art. 6(3) condition still adds the Art. 49(2)
# registration item there.
ANNEX_III_ANY = {"not": {"field": "annex_iii_area", "is": None}}
ANNEX_I_ROUTE = {
    "all": [
        {"field": "annex_i_safety_component", "is": True},
        {"field": "annex_i_third_party_assessment", "is": True},
    ]
}
# Facts the engine reads only once the system is high-risk (Art. 6 AIA) and not
# prohibited: a prohibited practice dominates every other tier.
HIGH_RISK_ROUTE = {
    "all": [
        IN_SCOPE,
        {"field": "prohibited_practices", "empty": True},
        {"any": [ANNEX_III_ANY, ANNEX_I_ROUTE]},
    ]
}
# Art. 27 AIA deployer status matters only on the Art. 6(2) route (an Annex III
# area), and only where the FRIA is not already settled by the Annex III point:
# 5(b) and 5(c) always need one, point 2 never does.
FRIA_OPEN = {
    "all": [
        HIGH_RISK_ROUTE,
        ANNEX_III_ANY,
        {"field": "roles", "has": Role.DEPLOYER.value},
        {
            "not": {
                "field": "annex_iii_area",
                "in": [
                    AnnexIII.CRITICAL_INFRASTRUCTURE.value,
                    AnnexIII.CREDITWORTHINESS.value,
                    AnnexIII.INSURANCE_LIFE_HEALTH.value,
                ],
            }
        },
    ]
}


def _dated_before(cut_off: str) -> dict[str, Any]:
    return {
        "any": [
            {"field": "placing_on_market_date", "before": cut_off},
            {"field": "putting_into_service_date", "before": cut_off},
        ]
    }


# A Section B product: the intake asks the act, never annex_i_section (NOT_ASKED), so the
# act alone decides the section here (SystemProfile.effective_annex_i_section).
SECTION_B = {
    "field": "annex_i_legislation",
    "in": [act.value for act in AnnexILegislation if act.section is AnnexISection.SECTION_B],
}

# Art. 111(2) AIA reads a significant change only for a high-risk system placed on the
# market or put into service before its Chapter III date (transitions.change_used): the
# Annex III date for an Annex III area, else the Annex I date, never for a Section B
# product without one. The dates come from the engine's constants; the browser only
# compares them.
CHANGE_OPEN = {
    "all": [
        HIGH_RISK_ROUTE,
        {
            "any": [
                {"all": [ANNEX_III_ANY, _dated_before(POINT_C_ANNEX_III)]},
                {
                    "all": [
                        {"not": ANNEX_III_ANY},
                        {"not": SECTION_B},
                        _dated_before(POINT_C_ANNEX_I),
                    ]
                },
            ]
        },
    ]
}

# Art. 49(3) and (5) AIA and the public-authority deployer in Art. 111(2) read the
# profile's own deployer role on a high-risk route (transitions.public_authority_status_used).
# The status changes the result on every Annex III point; on an Annex I route without one
# only for a system dated before the Annex I date, or undated, that is no Section B product
# and has no public_authority_use (the Art. 111(2) 2030 date). Exactly there, for a
# profile in scope, an unknown status raises an open question, so the intake asks it
# there and nowhere else.
_UNDATED = {
    "all": [
        {"field": "placing_on_market_date", "is": None},
        {"field": "putting_into_service_date", "is": None},
    ]
}
PUBLIC_AUTHORITY_STATUS_OPEN = {
    "all": [
        HIGH_RISK_ROUTE,
        {"field": "roles", "has": Role.DEPLOYER.value},
        {
            "any": [
                ANNEX_III_ANY,
                {
                    "all": [
                        {"not": SECTION_B},
                        {"field": "public_authority_use", "is": False},
                        {"any": [_dated_before(POINT_C_ANNEX_I), _UNDATED]},
                    ]
                },
            ]
        },
    ]
}

_ANSWERS = {
    "yes": "Yes",
    "no": "No",
    "unknown": "I don't know",
}


def _options(enum: type) -> list[dict[str, str]]:
    return [{"value": member.value, "label": option_label(member)} for member in enum]


# The eight areas of Annex III, headed as in the Official Journal (Regulation (EU)
# 2024/1689, Annex III, points 1 to 8; not amended by Regulation (EU) 2026/1744).
# tests/test_intake.py checks each heading against the pinned text in sources/.
ANNEX_III_AREAS: dict[str, str] = {
    "1": "Biometrics, in so far as their use is permitted under relevant Union or national law",
    "2": "Critical infrastructure",
    "3": "Education and vocational training",
    "4": "Employment, workers\u2019 management and access to self-employment",
    "5": "Access to and enjoyment of essential private services and essential public services "
    "and benefits",
    "6": "Law enforcement, in so far as their use is permitted under relevant Union or national "
    "law",
    "7": "Migration, asylum and border control management, in so far as their use is permitted "
    "under relevant Union or national law",
    "8": "Administration of justice and democratic processes",
}


def _annex_iii_groups() -> list[dict[str, Any]]:
    """The Annex III question in two steps (D5): the area, then its points.

    Presentation only: the answer stays the point (``annex_iii_area``), so the area
    never becomes a profile field and the interpreters read the question as one.
    """

    groups = []
    for area, heading in ANNEX_III_AREAS.items():
        points = [m.value for m in AnnexIII if m.value.split(".")[1:2] == [area]]
        groups.append({"value": area, "label": f"Point {area}: {heading}", "options": points})
    return groups


QUESTIONS: list[dict[str, Any]] = [
    {
        "id": "system",
        "kind": "details",
        "title": "About the system",
        "hint": "Plain facts for the report heading. Use synthetic or public facts in this demo.",
        "fields": [
            {"field": "name", "label": "System name", "required": True},
            {"field": "description", "label": "Short description"},
            {"field": "purpose", "label": "Intended purpose"},
            {"field": "sector", "label": "Sector"},
            {"field": "intended_purpose_source", "label": "Where the intended purpose is stated"},
        ],
    },
    {
        "id": "roles",
        "kind": "multi",
        "field": "roles",
        "title": "Which roles does your organisation hold for this system?",
        "hint": "Select every role that applies. A single company often holds several.",
        "options": _options(Role),
        "required": True,
        "unknown": BLOCK,
    },
    {
        "id": "is_ai_system",
        "kind": "boolean",
        "field": "is_ai_system",
        "title": "Is the software an AI system?",
        "hint": "As defined in the AI Act. Choose I don't know if this is not yet settled.",
        "article": "Art. 3(1) AIA",
        "unknown": {"value": None},
    },
    {
        "id": "eu_nexus",
        "kind": "boolean",
        "field": "eu_nexus",
        "title": "Is the system placed on the market, put into service or used in the EU?",
        "hint": "Including output used in the EU.",
        "article": "Art. 2 AIA",
        "unknown": {"value": None},
    },
    {
        "id": "excluded_use_flags",
        "kind": "multi",
        "field": "excluded_use_flags",
        "title": "Does any scope exclusion or carve-out possibly apply?",
        "hint": "A selection does not exclude the system. It routes the scope question to review.",
        "article": "Art. 2 AIA",
        "options": _options(ExcludedUse),
        "none_label": "None of these",
        "unknown": BLOCK,
    },
    {
        "id": "prohibited_practices",
        "kind": "multi",
        "field": "prohibited_practices",
        "title": "Does the system involve any of these practices?",
        "hint": "Each is a prohibited practice under Art. 5 AIA.",
        "article": "Art. 5 AIA",
        "options": _options(ProhibitedPractice),
        "none_label": "None of these",
        "show_if": IN_SCOPE,
        "unknown": BLOCK,
    },
    {
        "id": "annex_i_safety_component",
        "kind": "boolean",
        "field": "annex_i_safety_component",
        "title": "Is the system a product, or a safety component of a product, covered by "
        "the Union harmonisation legislation in Annex I?",
        "article": "Art. 6(1) AIA",
        "show_if": IN_SCOPE,
        "unknown": BLOCK,
    },
    {
        "id": "annex_i_third_party_assessment",
        "kind": "boolean",
        "field": "annex_i_third_party_assessment",
        "title": "Does that product need a third-party conformity assessment under that "
        "legislation?",
        "article": "Art. 6(1) AIA",
        "show_if": {"all": [IN_SCOPE, {"field": "annex_i_safety_component", "is": True}]},
        "unknown": BLOCK,
    },
    {
        "id": "annex_i_legislation",
        "kind": "single",
        "field": "annex_i_legislation",
        "title": "Which Union harmonisation legislation in Annex I covers that product?",
        # The engine derives the section from the act, so the intake asks the act and never
        # annex_i_section: machinery is Section B since Regulation (EU) 2026/1744. Whether
        # Art. 2(2) also displaces Art. 5, Art. 50 and Annex III duties is open (PENDING rows
        # in docs/REGULATORY_CLAIM_LEDGER.md), so the hint does not state it as settled.
        "hint": "The legislation decides the Annex I section. Art. 2(2) AIA limits a Section B "
        "product, machinery included, to the provisions it lists; the report keeps Art. 5, "
        "Art. 50 and any Annex III duties for review.",
        "article": "Art. 6(1) AIA",
        "options": _options(AnnexILegislation),
        # Off the Art. 6(1) route the engine reports a given act as unused.
        "show_if": {"all": [IN_SCOPE, ANNEX_I_ROUTE]},
        # Not known: the report keeps the Section A duties and goes to review.
        "unknown": {"value": None},
    },
    {
        "id": "annex_iii_area",
        "kind": "single",
        "field": "annex_iii_area",
        "title": "Is the system intended for a use listed in Annex III?",
        "hint": "Choose the area that applies, then the point. If an area applies but not "
        "which point, answer I don't know; it is treated as high-risk and routed to review.",
        "article": "Art. 6(2) AIA",
        "options": _options(AnnexIII),
        "groups": _annex_iii_groups(),
        "group_title": "Which use in this area is the system intended for?",
        "none_label": "None of these",
        "show_if": IN_SCOPE,
        "unknown": {"value": AnnexIII.UNSURE.value},
    },
    {
        "id": "used_for_financial_fraud_detection",
        "kind": "boolean",
        "field": "used_for_financial_fraud_detection",
        "title": "Is the system used for the purpose of detecting financial fraud?",
        "hint": "Annex III(5)(b) AIA excepts AI systems used for the purpose of detecting "
        "financial fraud. Yes or I don't know raises a review question; the system stays "
        "high-risk until it is answered.",
        "article": "Annex III(5)(b) AIA",
        # The engine reads the field only for an Annex III point 5(b) profile.
        "show_if": {
            "all": [IN_SCOPE, {"field": "annex_iii_area", "is": AnnexIII.CREDITWORTHINESS.value}]
        },
        "unknown": {"value": None},
    },
    {
        "id": "performs_profiling",
        "kind": "boolean",
        "field": "derogation.performs_profiling",
        "title": "Does the system perform profiling of natural persons?",
        "hint": "Profiling keeps an Annex III system high-risk.",
        "article": "Art. 6(3) AIA",
        "show_if": {"all": [IN_SCOPE, ANNEX_III_ANY]},
        "unknown": BLOCK,
    },
    {
        "id": "derogation",
        "kind": "flags",
        "title": "Does any of these Art. 6(3) conditions apply?",
        "hint": "An asserted condition never lowers the tier here. It keeps the system "
        "high-risk and routes the derogation to review.",
        "article": "Art. 6(3) AIA",
        "options": [
            {"field": f"derogation.{key}", "label": DEROGATION_LABELS[key]}
            for key in (
                "narrow_procedural_task",
                "improves_prior_human_activity",
                "detects_patterns_without_replacing_human",
                "preparatory_task",
            )
        ],
        "none_label": "None of these",
        "show_if": {
            "all": [
                IN_SCOPE,
                ANNEX_III_ANY,
                {"field": "derogation.performs_profiling", "is": False},
            ]
        },
        "unknown": BLOCK,
    },
    {
        "id": "deployer_public_law_body",
        "kind": "boolean",
        "field": "deployer_public_law_body",
        "title": "Is the deployer a body governed by public law?",
        "article": "Art. 27 AIA",
        "show_if": FRIA_OPEN,
        "unknown": BLOCK,
    },
    {
        "id": "deployer_private_public_service",
        "kind": "boolean",
        "field": "deployer_private_public_service",
        "title": "Is the deployer a private entity providing public services?",
        "article": "Art. 27 AIA",
        "show_if": FRIA_OPEN,
        "unknown": BLOCK,
    },
    {
        "id": "provider_established_outside_eu",
        "kind": "boolean",
        "field": "provider_established_outside_eu",
        "title": "Is the provider established outside the EU?",
        "article": "Art. 22 AIA",
        "show_if": HIGH_RISK_ROUTE,
        "unknown": BLOCK,
    },
    {
        "id": "has_authorised_representative",
        "kind": "boolean",
        "field": "has_authorised_representative",
        "title": "Has the provider appointed an authorised representative in the EU?",
        "article": "Art. 22 AIA",
        "show_if": {
            "all": [HIGH_RISK_ROUTE, {"field": "provider_established_outside_eu", "is": True}]
        },
        "unknown": BLOCK,
    },
    {
        "id": "value_chain",
        "kind": "flags",
        "title": "Does your organisation do either of these to the system?",
        "hint": "Either can make a distributor, importer or deployer a provider.",
        "article": "Art. 25 AIA",
        "options": [
            {
                "field": "puts_name_or_trademark_on_system",
                "label": "Puts its name or trademark on it",
            },
            {"field": "substantially_modifies_system", "label": "Substantially modifies it"},
        ],
        "none_label": "Neither",
        "show_if": HIGH_RISK_ROUTE,
        "unknown": BLOCK,
    },
    {
        "id": "is_gpai_model",
        "kind": "boolean",
        "field": "is_gpai_model",
        "title": "Is this a general-purpose AI model?",
        "show_if": IN_SCOPE,
        "unknown": BLOCK,
    },
    {
        "id": "training_flops",
        "kind": "number",
        "field": "training_flops",
        "title": "What was the cumulative training compute, in FLOP?",
        "hint": "For example 2e25, with the digits 0 to 9 (other digit forms and special "
        "spaces such as a no-break space are not accepted). Leave blank if not disclosed; the "
        "systemic-risk status then goes to review unless the model is designated.",
        "article": "Art. 51(2) AIA",
        "show_if": {"all": [IN_SCOPE, {"field": "is_gpai_model", "is": True}]},
    },
    {
        "id": "gpai_systemic_risk_designated",
        "kind": "boolean",
        "field": "gpai_systemic_risk_designated",
        "title": "Has the Commission designated the model as having systemic risk?",
        "article": "Art. 51(1)(b) AIA",
        "show_if": {"all": [IN_SCOPE, {"field": "is_gpai_model", "is": True}]},
        "unknown": BLOCK,
    },
    {
        "id": "transparency",
        "kind": "flags",
        "title": "Does the system do any of these?",
        "article": "Art. 50 AIA",
        "options": [
            {
                "field": "interacts_with_natural_persons",
                "label": "Interacts directly with natural persons (Art. 50(1))",
            },
            {
                "field": "generates_synthetic_content",
                "label": "Generates synthetic audio, image, video or text (Art. 50(2))",
            },
            {
                "field": "deploys_emotion_or_biometric_categorisation",
                "label": "Emotion recognition or biometric categorisation (Art. 50(3))",
            },
            {
                "field": "generates_deepfakes",
                "label": "Generates or manipulates deep fakes (Art. 50(4))",
            },
        ],
        "none_label": "None of these",
        "show_if": IN_SCOPE,
        "unknown": BLOCK,
    },
    {
        "id": "public_authority_use",
        "kind": "boolean",
        "field": "public_authority_use",
        "title": "Is the system intended to be used by public authorities?",
        "unknown": BLOCK,
    },
    {
        "id": "dates",
        "kind": "details",
        "title": "Dates",
        "hint": "YYYY-MM-DD. The assessment date is the date of the placing on the market, "
        "putting into service or use under assessment; blank leaves date-dependent results "
        "open, for review. Leave a market date blank if the system was not yet placed on the "
        "market or put into service, or if the date is not known; for a system generating "
        "synthetic content a blank placing date goes to review (Art. 111(4) AIA). For "
        "Art. 111(2) AIA the date the first unit of that type and model was placed on the "
        "Union market or put into service decides (recital 39 of Regulation (EU) 2026/1744). "
        "A general-purpose AI model's own date is asked next.",
        "article": "Art. 111(2) AIA",
        "fields": [
            {"field": "assessment_date", "label": "Assessed on", "type": "date"},
            {"field": "placing_on_market_date", "label": "Placed on the market", "type": "date"},
            {"field": "putting_into_service_date", "label": "Put into service", "type": "date"},
        ],
    },
    {
        "id": "gpai_date",
        "kind": "details",
        "title": "General-purpose AI model date",
        "hint": "YYYY-MM-DD. Leave blank if not given: the model is then dated by the AI "
        "system's placing-on-market date, for review, or, if none is given, the Art. 111(3) "
        "date of its obligations is open and goes to review.",
        "article": "Art. 111(3) AIA",
        "fields": [
            {
                "field": "gpai_model_placing_on_market_date",
                "label": "Model placed on the market",
                "type": "date",
            }
        ],
        # For a profile that screens no general-purpose AI model the engine reports the
        # date as not used.
        "show_if": {"all": [IN_SCOPE, {"field": "is_gpai_model", "is": True}]},
    },
    {
        "id": "significant_change",
        "kind": "boolean",
        "field": "significant_change_after_application_date",
        "title": "Has the system changed significantly after the relevant application date?",
        "hint": "Asked because a date before the system's Chapter III date is given: such a "
        "system comes under the Regulation, apart from Art. 5, only once its design changes "
        "significantly as from that date.",
        "article": "Art. 111(2) AIA",
        # Elsewhere the engine reports a given answer as not used.
        "show_if": CHANGE_OPEN,
        # Where it is asked, null always raises the Art. 111(2) open question.
        "unknown": {"value": None},
    },
    {
        "id": "deployer_public_authority",
        "kind": "boolean",
        "field": "deployer_public_authority",
        "title": "Is the deployer a public authority or a Union institution, body, office or "
        "agency, or does it act on behalf of one?",
        "article": "Art. 49(3), Art. 49(5) and Art. 111(2) AIA",
        "show_if": PUBLIC_AUTHORITY_STATUS_OPEN,
        # Where it is asked, null raises an open question wherever the status changes the
        # result: Art. 49(3) or (5) on an Annex III point, Art. 111(2) for a legacy or
        # undated system on an Annex I route (engine._art_49_3_questions and
        # engine._art_111_2_questions).
        "unknown": {"value": None},
    },
]


# Profile fields the intake does not ask. annex_i_section is derived from the act the
# intake asks (annex_i_legislation). The Art. 5(1)(ba) and (bb) element screens are given
# in a JSON profile; a guided profile leaves them unscreened, so a generator goes to review
# with rules.prohibited.LATER_SCREEN_QUESTION.
NOT_ASKED = ("annex_i_section", "intimate_imagery", "child_sexual_abuse_material")


def intake_definition() -> dict[str, Any]:
    defaults = SystemProfile(name="x").model_dump(mode="json")
    defaults["name"] = ""
    return {
        "schema": SCHEMA_ID,
        "answers": _ANSWERS,
        "defaults": defaults,
        "questions": QUESTIONS,
    }


# --- Interpreter (mirrored by docs/playground/intake.mjs) ---------------------


def read_field(profile: dict[str, Any], field: str) -> Any:
    value: Any = profile
    for part in field.split("."):
        value = value.get(part) if isinstance(value, dict) else None
    return value


def write_field(profile: dict[str, Any], field: str, value: Any) -> None:
    *parents, last = field.split(".")
    target = profile
    for part in parents:
        target = target.setdefault(part, {})
    target[last] = value


def holds(condition: dict[str, Any] | None, profile: dict[str, Any]) -> bool:
    if condition is None:
        return True
    if "all" in condition:
        return all(holds(c, profile) for c in condition["all"])
    if "any" in condition:
        return any(holds(c, profile) for c in condition["any"])
    if "not" in condition:
        return not holds(condition["not"], profile)
    value = read_field(profile, condition["field"])
    if "is" in condition:
        return value == condition["is"] and type(value) is type(condition["is"])
    if "in" in condition:
        return value in condition["in"]
    if "has" in condition:
        return isinstance(value, list) and condition["has"] in value
    if "empty" in condition:
        return (not value) == condition["empty"]
    if "before" in condition:
        # ISO dates compare as strings; answers are validated as dates before they apply.
        return isinstance(value, str) and value < condition["before"]
    raise ValueError(f"unknown condition {condition!r}")


def question_fields(question: dict[str, Any]) -> list[str]:
    if question["kind"] in ("details", "flags"):
        key = "fields" if question["kind"] == "details" else "options"
        return [entry["field"] for entry in question[key]]
    return [question["field"]]


def _base_profile() -> dict[str, Any]:
    profile = intake_definition()["defaults"]
    return {
        key: (dict(value) if isinstance(value, dict) else value) for key, value in profile.items()
    }


# One grammar for both interpreters (NUMBER in intake.mjs): a decimal with an
# optional exponent, so "2e25" passes and "0x10" or "1_000" do not, in either.
# ASCII digits only, and only ASCII whitespace is trimmed (NUMBER_SPACE in
# intake.mjs): str.strip() and String.prototype.trim() each remove characters the
# other keeps, and Python's \d and float() also take other Unicode digits. The
# pattern reads a run of digits in one way only, so a long text that is not a
# number is refused in time proportional to its length.
_NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$", re.ASCII)
_NUMBER_SPACE = " \t\n\v\f\r"


def _number_text(value: str) -> str:
    return value.strip(_NUMBER_SPACE)


def _is_number(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int | float):
        try:
            return math.isfinite(value)
        except OverflowError:
            # An int beyond the float range: JSON.parse reads that literal as Infinity.
            return False
    if not isinstance(value, str):
        return False
    text = _number_text(value)
    if not _NUMBER.match(text):
        return False
    try:
        return math.isfinite(float(text))
    except (ValueError, OverflowError):
        return False


def is_answered(question: dict[str, Any], answers: dict[str, Any]) -> bool:
    """Whether the question has a usable answer (mirrors ``isAnswered`` in intake.mjs)."""

    present = question["id"] in answers
    answer = answers.get(question["id"])
    kind = question["kind"]
    if kind == "details":
        values = answer if isinstance(answer, dict) else {}
        return all(
            not entry.get("required") or str(values.get(entry["field"]) or "").strip()
            for entry in question["fields"]
        )
    if kind == "boolean":
        return answer in ("yes", "no")
    if kind == "single":
        return (answer == "none" and bool(question.get("none_label"))) or any(
            o["value"] == answer for o in question["options"]
        )
    if kind == "multi":
        values = {o["value"] for o in question["options"]}
        return (
            isinstance(answer, list)
            and (not question.get("required") or bool(answer))
            and all(v in values for v in answer)
        )
    if kind == "flags":
        return isinstance(answer, list)
    if kind == "number":
        return present and (answer in ("", None) or _is_number(answer))
    return False


def answers_to_profile(
    answers: dict[str, Any],
) -> tuple[dict[str, Any], list[str], list[str], list[str]]:
    """Apply answers in question order.

    Returns (profile, asked ids, blocked ids, missing ids). A question is asked only
    if its condition holds on the profile built from the answers before it; a
    missing answer leaves its fields at their defaults and is reported, never
    filled in.
    """

    profile = _base_profile()
    asked: list[str] = []
    blocked: list[str] = []
    missing: list[str] = []
    for question in QUESTIONS:
        if not holds(question.get("show_if"), profile):
            continue
        asked.append(question["id"])
        answer = answers.get(question["id"])
        if answer == UNKNOWN:
            policy = question.get("unknown")
            if policy == BLOCK or policy is None:
                blocked.append(question["id"])
            else:
                write_field(profile, question["field"], policy["value"])
            continue
        if not is_answered(question, answers):
            missing.append(question["id"])
            continue
        kind = question["kind"]
        if kind == "details":
            for entry in question["fields"]:
                text = str((answer or {}).get(entry["field"]) or "").strip()
                is_date = entry.get("type") == "date"
                write_field(profile, entry["field"], (text or None) if is_date else text)
        elif kind == "boolean":
            write_field(profile, question["field"], answer == "yes")
        elif kind == "single":
            write_field(profile, question["field"], None if answer == "none" else answer)
        elif kind == "multi":
            write_field(profile, question["field"], list(answer))
        elif kind == "flags":
            for option in question["options"]:
                write_field(profile, option["field"], option["field"] in answer)
        elif kind == "number":
            if answer in ("", None):
                number = None
            else:
                number = float(_number_text(answer) if isinstance(answer, str) else answer)
            write_field(profile, question["field"], number)
    return profile, asked, blocked, missing


def profile_to_answers(profile: dict[str, Any]) -> dict[str, Any]:
    """The answers that reproduce ``profile``: used to open an example in the intake."""

    full = _base_profile()
    for key, value in profile.items():
        if key == "derogation":
            full["derogation"].update(value)
        elif key != "$schema":
            full[key] = value
    answers: dict[str, Any] = {}
    for question in QUESTIONS:
        kind = question["kind"]
        if kind == "details":
            answers[question["id"]] = {
                entry["field"]: read_field(full, entry["field"]) or ""
                for entry in question["fields"]
            }
        elif kind == "flags":
            answers[question["id"]] = [
                option["field"]
                for option in question["options"]
                if read_field(full, option["field"])
            ]
        else:
            value = read_field(full, question["field"])
            if kind == "boolean":
                # null is "I don't know" only where that answer writes null; any
                # other null (a model default) is left unanswered for the user.
                if value is not None:
                    answers[question["id"]] = "yes" if value else "no"
                elif question.get("unknown") == {"value": None}:
                    answers[question["id"]] = UNKNOWN
            elif kind == "single":
                if value is not None:
                    answers[question["id"]] = value
                elif question.get("none_label"):
                    answers[question["id"]] = "none"
            elif kind == "multi":
                answers[question["id"]] = list(value)
            elif kind == "number":
                answers[question["id"]] = "" if value is None else value
    return answers
